OC.L10N.register(
    "fulltextsearch_elasticsearch",
    {
    "Full text search - Elasticsearch Platform" : "全文検索 - Elasticsearch Platform",
    "Index using ElasticSearch" : "ElasticSearchを使用したインデックス",
    "Extension to the _Full text search_ app to communicate with ElasticSearch." : "ElasticSearchと通信するための_フルテキスト検索_アプリへの拡張。",
    "Elastic Search" : "Elastic Search",
    "Address of the Servlet" : "サーブレットのアドレス",
    "Include your credential in case authentication is required." : "認証が必要な場合は、資格情報を含めてください。",
    "Index" : "インデックス",
    "Name of your index." : "インデックスの名前。",
    "[Advanced] Analyzer tokenizer" : "[Advanced] アナライザ トークナイザ",
    "Some language might needs a specific tokenizer." : "言語によっては、特定のトークナイザが必要な場合があります。"
},
"nplurals=1; plural=0;");
