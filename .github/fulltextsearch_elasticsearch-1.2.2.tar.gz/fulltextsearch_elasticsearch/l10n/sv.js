OC.L10N.register(
    "fulltextsearch_elasticsearch",
    {
    "Full text search - Elasticsearch Platform" : "Fulltextsökning - ElasticSearch Platform",
    "Index using ElasticSearch" : "Indexera med ElasticSearch",
    "Elastic Search" : "Elastic Search",
    "Address of the Servlet" : "Adress till Servlet",
    "Include your credential in case authentication is required." : "Inkludera dina inloggningsuppgifter ifall autentisering krävs.",
    "Index" : "Index",
    "Name of your index." : "Namn på ditt index"
},
"nplurals=2; plural=(n != 1);");
