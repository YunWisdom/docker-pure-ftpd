OC.L10N.register(
    "fulltextsearch_elasticsearch",
    {
    "Full text search - Elasticsearch Platform" : "Koko tekstin haku - Elasticsearch-alusta",
    "Index using ElasticSearch" : "Indeksi ElasticSearchia käyttäen",
    "Elastic Search" : "Elastic Search",
    "Address of the Servlet" : "Servletin osoite",
    "Include your credential in case authentication is required." : "Sisällytä tunnistustiedot, jos tunnistautuminen vaaditaan.",
    "Index" : "Indeksi",
    "Name of your index." : "Indeksin nimi."
},
"nplurals=2; plural=(n != 1);");
