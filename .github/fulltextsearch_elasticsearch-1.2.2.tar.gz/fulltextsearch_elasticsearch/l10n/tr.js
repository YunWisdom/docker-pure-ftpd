OC.L10N.register(
    "fulltextsearch_elasticsearch",
    {
    "Full text search - Elasticsearch Platform" : "Tam metin arama - ElasticSearch Platformu",
    "Index using ElasticSearch" : "ElasticSearch ile dizin oluşturulsun",
    "Extension to the _Full text search_ app to communicate with ElasticSearch." : "ElasticSearch ile iletişim kuracak _Full text search_ uygulama eklentisi.",
    "Elastic Search" : "Elastic Search",
    "Address of the Servlet" : "Sunucu Kodunun Adresi",
    "Include your credential in case authentication is required." : "Kimlik doğrulaması gerekiyorsa kimlik bilgilerinizi katın.",
    "Index" : "Dizin",
    "Name of your index." : "Dizin adı.",
    "[Advanced] Analyzer tokenizer" : "[Gelişmiş] İnceleyici kodlayıcı",
    "Some language might needs a specific tokenizer." : "Bazı diller için özel bir kodlayıcı gerekebilir."
},
"nplurals=2; plural=(n > 1);");
