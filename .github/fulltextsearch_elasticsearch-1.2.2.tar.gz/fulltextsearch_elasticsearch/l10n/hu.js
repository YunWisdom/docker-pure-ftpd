OC.L10N.register(
    "fulltextsearch_elasticsearch",
    {
    "Full text search - Elasticsearch Platform" : "Teljes szöveges keresés - Rugalmas keresés Platform",
    "Index using ElasticSearch" : "Indexelés RugalmasKeresés használatával",
    "Extension to the _Full text search_ app to communicate with ElasticSearch." : "_Teljes szöveges keresés_ app kiterjesztés a RugalmasKeresés-hez való kommunikációhoz",
    "Elastic Search" : "Rugalmas Keresés",
    "Address of the Servlet" : "A Servlet címe",
    "Include your credential in case authentication is required." : "Bejelentkezési adataid használata ha hitelesítés szükséges.",
    "Index" : "Index",
    "Name of your index." : "Az indexed neve.",
    "[Advanced] Analyzer tokenizer" : "[Haladó] Lexikális szövegbontásos elemzés",
    "Some language might needs a specific tokenizer." : "Némely nyelvhez specifikus lexikális szövegbontásra lehet szükség"
},
"nplurals=2; plural=(n != 1);");
