OC.L10N.register(
    "fulltextsearch_elasticsearch",
    {
    "Full text search - Elasticsearch Platform" : "Leit í öllum textanum - Elasticsearch-kerfið",
    "Index using ElasticSearch" : "Gera atriðaskrá með ElasticSearch",
    "Extension to the _Full text search_ app to communicate with ElasticSearch." : "Viðbót fyrir _Full text search_ forritið til að eiga samskipti við ElasticSearch.",
    "Elastic Search" : "Teygjanleg leit",
    "Address of the Servlet" : "Vistfang forritlingsins (servlet)",
    "Include your credential in case authentication is required." : "Hafðu með auðkennin þín ef auðkenningar verður krafist.",
    "Index" : "Atriðaskrá",
    "Name of your index." : "Nafn á atriðaskránni þinni.",
    "[Advanced] Analyzer tokenizer" : "[Meira] Greining teikna (Analyzer tokenizer)",
    "Some language might needs a specific tokenizer." : "Einhver tungumál gætu þarfnast sérstaks teiknabiðlara."
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
