OC.L10N.register(
    "fulltextsearch_elasticsearch",
    {
    "Full text search - Elasticsearch Platform" : "Volltextsuche - Elasticsearch Plattform",
    "Index using ElasticSearch" : "Indizieren mittels ElasticSearch",
    "Extension to the _Full text search_ app to communicate with ElasticSearch." : "Erweiterung für die _Full text search_ App um sich mit ElasticSearch zu verbinden.",
    "Elastic Search" : "ElasticSearch",
    "Address of the Servlet" : "Adresse des Servlets",
    "Include your credential in case authentication is required." : "Gebe Deine Anmeldedaten für den Fall, dass eine Anmeldung erforderlich ist ein.",
    "Index" : "Index",
    "Name of your index." : "Name Deines Indexes",
    "[Advanced] Analyzer tokenizer" : "[Advanced] Analyzer tokenizer",
    "Some language might needs a specific tokenizer." : "Einige Sprachen benötigen möglicherweise einen bestimmten Tokenizer."
},
"nplurals=2; plural=(n != 1);");
