var MODULE = (function (radio) {

  /* Click on menus */
  $('a.nav-icon-files').click(function(e) {
    e.preventDefault();
    radio.switch_menu(0);
  });

  $('a.nav-icon-recent').click(function(e) {
    e.preventDefault();
    radio.switch_menu(1);
  });

  $('a.nav-icon-favorites').click(function(e) {
    e.preventDefault();
    radio.switch_menu(2);
  });

  $('a.nav-icon-systemtagsfilter').click(function(e) {
    e.preventDefault();
    radio.switch_menu(3);
  });

  radio.load_menu_state = function() {
    var menu_state = 0;
    var baseUrl = OC.generateUrl('/apps/radio/getMenuState');
    $.get(baseUrl, function ( data ) {
      if ("menu_state" in data) {
        menu_state = data["menu_state"];
      }
      radio.switch_menu(menu_state);
      return true;
    });
  }

  radio.save_menu_state = function(menu_state) {
    var baseUrl = OC.generateUrl('/apps/radio/saveMenuState');
    var settings = {
      "menu_state": menu_state
    };
    $.ajax({
            url: baseUrl,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(settings)
    }).done(function(data){
      return true;
    });
  }

  radio.switch_menu = function(type) {

      var state = Number(type);

      $('#filestable').hide();
      $('#emptycontent').addClass('hidden');
      $('.nofilterresults').addClass('hidden');
      $('.loading').removeClass('hidden');

      clearTimeout(searchTimeout);
      searchTimeout = setTimeout(function(){
        $('#app-navigation').find('li').removeClass("active");
        $("tbody > tr").remove();
        radio.save_menu_state(state)
        switch (state) {
          case 0:
            history.pushState("", "", "#top");
            $('li.nav-files').addClass('active');
            radio.radio_query(1);
            break;
          case 1:
            history.pushState("", "", "#recent");
            $('li.nav-recent').addClass('active');
            radio.radio_query(2);
            break;
          case 2:
            history.pushState("", "", "#favorites");
            $('li.nav-favorites').addClass('active');
            radio.action_load_favorites();
            break;
          case 2:
            history.pushState("", "", "#categories");
            $('li.nav-categories').addClass('active');
            radio.action_load_categories();
            break;
        }
      }, 500);
  };

  // On app start, load top list
  if(window.location.hash) {
    var hash = String(window.location.hash.replace('#',''));
    switch(hash) {
      case "top":
        radio.switch_menu(0);
        break;
      case "recent":
        radio.switch_menu(1);
        break;
      case "favorites":
        radio.switch_menu(2);
        break;
      default:
        radio.switch_menu(0);
        break;
    }
  } else {
    radio.load_menu_state();
  };

  return radio;
}(MODULE || {}));
