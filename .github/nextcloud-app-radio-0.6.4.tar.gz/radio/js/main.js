var MODULE = (function (radio) {

  var version = "0.6.3"

  $(document).ready(function () {

      // Scroll event handler
      $(window).scroll(function(){
        var station_list = $("#app-content-files");
        if ( ( $(window).scrollTop() + $(window).height() ) == $(document).height() ) {
          if(!station_list.data("didfire")) {
            station_list.data("didfire", true);
            if ($('li.nav-files').hasClass('active')){
              radio.radio_query(1, "");
            } else if ($('li.nav-recent').hasClass('active')) {
              radio.radio_query(2, "");
            } else if ($('li.nav-favorites').hasClass('active')) {
              console.log("todo");
            } else {
              var query = $('#searchbox').val();
              radio.radio_query(0, query);
            };
            var ref = station_list;
            setTimeout(function(){
              ref.data("didfire", false);
            }, 500);
          };
        };
      });

  });

  searchTimeout = null;
  var scheduled;

  /* ==============
  //   EVENTS    //
  /===============*/

  /* Click on a radio station (table entry) and play it */
  $('body').on('click', '.filename', function(e) {
    e.preventDefault();
    $('#playbutton').attr("class", "buffering");
    var stationid = $(this).parent().attr('data-id');
    var stationname = $(this).parent().find('.nametext').text();
    radio.action_play(stationid);
    $('#player').attr('data-id',stationid);
    $("#station_metadata").html("Playing: "+stationname);

    /* dirty fix missing background color for first td */
    $('tbody tr').css("background-color", "white");
    $(this).parent().css("background-color", "#f8f8f8");

    var element = document.getElementById('station_metadata');
    if (radio.isElementOverflowing(element)) {
      radio.wrapContentsInMarquee(element);
    };
    if (!scheduled){
      radio.schedule_get_metadata(stationid);
    };
  });

  /* Save station to favorites */
  $('body').on('click', '.favorite', function() {
    var stationid = $(this).parent().parent().attr('data-id');
    radio.action_favorite(stationid);
  });

  /* ==============
  //   ACTIONS    //
  /===============*/

  radio.schedule_get_metadata = function(stationid){
    scheduled = true;
    var stationid = $('#player').attr('data-id');
    req = $.get('https://onny.project-insanity.org/getmetadata/'+stationid, function(data) {
        if (data.hasOwnProperty('metadata')) {
          var metadata = data['metadata'].toString();
          if (metadata != $("#station_metadata").text()) {
            $("#station_metadata").html(metadata);
            var element = document.getElementById('station_metadata');
            if (radio.isElementOverflowing(element)) {
              radio.wrapContentsInMarquee(element);
            };
          };
          setTimeout(function(){radio.schedule_get_metadata(stationid);}, 10000);
        } else {
          scheduled = false;
        };
    }).fail(function(){
      scheduled = false;
    });
  };

  radio.action_favorite = function(stationid){

    var removed = false;
    var stations = [];
    var baseUrl = OC.generateUrl('/apps/radio');

    $.get(baseUrl + '/stations', function ( data ) {
      for (var station in data) {
        if (data[station]["stationid"] == stationid){
            removed = true;
            $.ajax({
              url: baseUrl + '/stations/' + data[station]["id"],
              method: 'DELETE'
            }).done(function(){
              $( "tr[data-id='" + stationid + "']" ).find('.icon-stationfav').removeClass('starred');
            });
        };
      };

      if (removed == true) {
        return true;
      } else {
        var station = {
          "stationid": stationid
        };
        $.ajax({
                url: baseUrl + '/stations',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(station)
        }).done(function(){
          $( "tr[data-id='"+stationid+"']" ).find('.icon-stationfav').addClass('starred');
        });
      };
    });
  };

  radio.render_results = function(data){

    var baseUrl = OC.generateUrl('/apps/radio');
    $.get(baseUrl + '/stations', function ( fav_stations ) {

      if (data.length == 0) {
        $('#filestable').hide();
        $('#emptycontent').addClass('hidden');
        $('.nofilterresults').removeClass('hidden');
        $('.loading').addClass('hidden');
      } else {
        $('#emptycontent').addClass('hidden');
        $('#filestable').show();
        $('.nofilterresults').addClass('hidden');
        $('.loading').addClass('hidden');
      };

      $.each(data, function(i, station) {

        var isstarred = ""

        for (var fav_station in fav_stations) {
          if (fav_stations[fav_station]["stationid"] == station['id']) {
            isstarred = "starred";
            break;
          }
        };

        $('tbody').append('<tr data-src="'+station['url']+'" data-id="'+station['id']+'">\
                            <td class="favcolumn">\
                              <a href="#" class="favorite">\
                                <span class="icon-stationfav ' + isstarred + '"></span>\
                                <span class="hidden-visually">Favorite</span>\
                              </a>\
                            </td>\
                            <td class="filename">\
                              <label for="select-files-3">\
                                <div class="thumbnail" style="background-image:url('+station['favicon']+'); background-size: 32px;"></div>\
                              </label>\
                              <a class="name" href="#">\
                                <span class="nametext"><span class="innernametext">'+station['name']+'</span></span>\
                              </a>\
                            </td>\
                          </tr>');
      });

    });
  }

  radio.action_load_favorites = function(){
      var stations = []
      var baseUrl = OC.generateUrl('/apps/radio');

      $.get(baseUrl + '/stations', function ( data ) {
        for (var station in data) {
          stations.push(data[station]["stationid"]);
        };
        if (stations.length == 0) {
          $('#filestable').hide();
          $('#emptycontent').removeClass('hidden');
          $('.loading').addClass('hidden');
        } else {
          console.log(stations);
          radio.query_stations(stations);
        };
      });
  };

  radio.query_stations = function(station_ids){
    var station_array = [];
    var station_array_new = [];

    station_ids.forEach(function (station_id, idx) {
      var url = "https://www.radio-browser.info/webservice/json/stations/byid/"+station_ids[idx];
      $.getJSON( url , {"User-Agent": "Nextcloud Radio/"+version }, function( data ) {

        if (data.length === 0) {
          station_array = station_array.concat([{'id': station_id, 'name': 'Broken radio station entry :(', 'favicon': '', 'url': ''}])
        } else {
          station_array = station_array.concat(data);
        };

        if (station_ids.length == station_array.length){

          // sorting results array
          station_ids.forEach( function (station_id) {
            station_array.forEach( function (station) {
              if (station_id === station['id']) {
                station_array_new = station_array_new.concat(station);
              };
            });
          });

          radio.render_results(station_array_new);
        };

      });
    });

  };

  radio.radio_query = function(type, query){
    var offset = $('tbody > tr').length;
    switch (type) {
      case 0:
        var url = "https://www.radio-browser.info/webservice/json/stations/search";
        break;
      case 1:
        var url = "https://www.radio-browser.info/webservice/json/stations/topclick";
        break;
      case 2:
        var url = "https://www.radio-browser.info/webservice/json/stations/lastchange";
        break;
    };
    $.ajax({
      method: "POST",
      url: url,
      data: {
        name: query,
        limit: 20,
        "User-Agent": "Nextcloud Radio/"+version,
        offset: offset
      },
      dataType: 'json',
    }).success( function(data){
      radio.render_results(data);
    });
  };

  // Search function
  new OCA.Search(function (query) {
    $('#app-navigation').find('li').removeClass("active");
    $("tbody > tr").remove();
    radio.radio_query(0, query);
  }, function (arg) {
    radio.switch_menu(0);
  });

  radio.action_load_categories = function (){
    $('#emptycontent').addClass('hidden');
    $('#filestable').show();
    $('.nofilterresults').addClass('hidden');
    $('.loading').addClass('hidden');
    $('tbody').append('<tr>\
                        <td class="favcolumn">\
                          <a href="#" class="favorite">\
                            <span class="icon-stationfav"></span>\
                            <span class="hidden-visually">Favorite</span>\
                          </a>\
                        </td>\
                        <td class="filename">\
                          <label for="select-files-3">\
                            <div class="thumbnail" style="background-image:url(); background-size: 32px;"></div>\
                          </label>\
                          <a class="name" href="#">\
                            <span class="nametext"><span class="innernametext">Languages</span></span>\
                          </a>\
                        </td>\
                      </tr>');
  };

  return radio;
}(MODULE || {}));
