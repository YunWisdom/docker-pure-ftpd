<?php
  style('radio', 'main');
  script('radio', 'main');
  script('radio', 'navigation');
  script('radio', 'player');
?>

    <div id="content" class="app-radio" role="main">
        <div id="app-navigation">
            <ul class="with-icon">
                <li data-id="files" class="nav-files">
                    <a href="#top" class="nav-icon-files svg">
                      <?php p($l->t('Top')); ?>
                    </a>
                </li>
                <li data-id="recent" class="nav-recent">
                    <a href="#recent" class="nav-icon-recent svg">
                      <?php p($l->t('Recent')); ?>
                    </a>
                </li>
                <li data-id="favorites" class="nav-favorites">
                    <a href="#favorites" class="nav-icon-favorites svg">
                      <?php p($l->t('Favorites')); ?>
                    </a>
                </li>
                <li data-id="categories" class="nav-categories">
                    <a href="#categories" class="nav-icon-systemtagsfilter svg">
                      <?php p($l->t('Categories')); ?>
                    </a>
                </li>
            </ul>
            <div id="app-settings">
                <audio id="player" src=""></audio>
                <button id="playbutton" class="play"></button>
                <div id="volumeicon" class="full"></div>
                <div id="volumeslider"></div>
                <p id="station_metadata"></p>
            </div>
        </div>
    <div id="app-content">
        <div id="app-content-files" class="viewcontainer">

            <div class="nofilterresults emptycontent hidden">
            	<div class="icon-search"></div>
            	<h2><?php p($l->t('No stations found with this name')); ?></h2>
            	<p></p>
            </div>

            <div class="loading emptycontent hidden">
            </div>

            <div id="emptycontent" class="hidden">
            	<div class="icon-starred"></div>
            	<h2><?php p($l->t('No favorites yet')); ?></h2>
            	<p><?php p($l->t('Stations you mark as favorite will show up here')); ?></p>
            </div>

            <table id="filestable" data-preview-x="32" data-preview-y="32">
                <thead>
                    <tr>
                        <th id='headerName' class=" column-name" colspan="2">
                            <div id="headerName-container">
                                <a class="name sort columntitle" data-sort="name"><span>Name</span><span class="sort-indicator"></span></a>
                            </div>
                        </th>
                    </tr>
                </thead>
                <tbody id="fileList">
                </tbody>
                <tfoot>
                </tfoot>
            </table>

            <div id="preload-01"></div>
            <div id="preload-02"></div>
            <div id="preload-03"></div>
            <div id="preload-04"></div>
        </div>
    </div>
    <!-- closing app-content -->
