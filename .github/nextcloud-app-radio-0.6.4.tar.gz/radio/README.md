# Nextcloud Radio app
This experimental app uses the radio-browser.info api and offers radio stations right in your Nextcloud!

[![](https://onny.project-insanity.org/files/nextcloud-app-radio-screenshot2.png)](https://onny.project-insanity.org/files/nextcloud-app-radio-screenshot2.png)

## Features

- [x] Browse hundreds of radio stations world wide and play them directly
- [x] Save stations to your favorites list
- [] Smooth playback with audio transitions
- [] Explore new stations in the category section

## Maintainers
* [Jonas Heinrich](https://github.com/onny)

## Installation

 * **From the appstore:** The most recent and stable version of the app can be found in the [official appstore](https://apps.nextcloud.com/apps/radio).
 * **Using git:** In your `nextcloud/apps/` directory, run `git clone https://git.project-insanity.org/onny/nextcloud-app-radio.git radio`. Then go to the Apps manager tab in your Nextcloud web interface, and enable the Radio app.
 * **Using the zip archive:** Download the latest [tar.bz2 archive](https://git.project-insanity.org/onny/nextcloud-app-radio/repository/archive.tar.bz2?ref=master), extract the directory inside your `nextcloud/apps/` directory, and rename it to `radio`. For stable releases, you can also download one of the [releases](https://git.project-insanity.org/onny/nextcloud-app-radio/) tar.bz2 archives. Then go to the Apps manager tab in your Nextcloud web interface, and enable the Radio app.
 * **Using package manager:** For ArchLinux, there is an [AUR package](https://aur.archlinux.org/packages/nextcloud-app-radio-git/) available.

## Testing
Can be easily tested using Docker:
```
docker run -v /tmp/nextcloud-app-radio:/opt/nextcloud/apps/radio -d --name nextcloud -p 80:80 rootlogin/nextcloud
```
First part of -v is the path to the cloned or downloaded nextcloud radio app. Debug running container it with:
```
docker exec -i -t 665b4a1e17b6 /bin/bash
```
Where -t specifies the container id. If you further need to access the sqlite-database, logs or files inside the data folder of Nextcloud, that you also have to share this folder with the host:
```
docker run -v /tmp/dockerdata:/data/data -v /tmp/nextcloud-app-radio:/opt/nextcloud/apps/radio -d --name nextcloud -p 80:80 rootlogin/nextcloud
```

## Reporting bugs
You can report bugs in the public gitlab repository [here](https://git.project-insanity.org/onny/nextcloud-app-radio/issues) and for discussion you can find a section for the app in the offical Nextcloud forums [here](https://help.nextcloud.com/c/apps/radio).

## Adding translations
For now only German translations are provided, so please submit your translations if possible :) It's really easy, just `git clone` this repo and copy the translation files in `l10n` according to your locale. Merge requests go to [this radio repository](https://git.project-insanity.org/onny/nextcloud-app-radio).

## Adding radio stations
This app uses a public and open database of radio stations as its backend, so any station you add in [radio-browser.info](http://www.radio-browser.info/) (no account required), will be also available in this app. Feel free to contribute :)

## Credits
* [radio-browser.info](http://www.radio-browser.info/) database api as backend for this app
* Python example code to query stream metadata, took from [here](https://anton.logvinenko.name/en/blog/how-to-get-title-from-audio-stream-with-python.html).

## Donation
If you like this app and want to support my work, you can donate to this Bitcoin address:
```
19mpmuNczGDgdxaBLBn3REEpQLPPcJHZB6
```
