OC.L10N.register(
    "radio",
    {
    "Top" : "Best bewertet",
    "Recent" : "Neu hinzugekommen",
    "Favorites" : "Favoriten",
    "Categories" : "Kategorien"
},
"nplurals=2; plural=(n != 1);");
