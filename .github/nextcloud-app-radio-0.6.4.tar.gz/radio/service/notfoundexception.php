<?php

namespace OCA\OwnNotes\Service;


class NotFoundException extends ServiceException {}