<?php

namespace OCA\OwnNotes\Service;

use Exception;

class ServiceException extends Exception {}