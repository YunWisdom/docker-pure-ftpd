<?php
namespace OCA\Radio\Db;

use OCP\IDBConnection;
use OCP\AppFramework\Db\Mapper;

class StationMapper extends Mapper {

    public function __construct(IDBConnection $db) {
        parent::__construct($db, 'radio_stations', '\OCA\Radio\Db\Station');
    }

    public function find($id, $userId) {
        $sql = 'SELECT * FROM *PREFIX*radio_stations WHERE id = ? AND user_id = ?';
        return $this->findEntity($sql, [$id, $userId]);
    }

    public function findAll($userId) {
        $sql = 'SELECT * FROM *PREFIX*radio_stations WHERE user_id = ?';
        return $this->findEntities($sql, [$userId]);
    }

}
