<?php
namespace OCA\Radio\Db;

use JsonSerializable;

use OCP\AppFramework\Db\Entity;

class Station extends Entity implements JsonSerializable {

    protected $stationid;
    protected $userId;

    public function jsonSerialize() {
        return [
            'id' => $this->id,
            'stationid' => $this->stationid,

        ];
    }
}
