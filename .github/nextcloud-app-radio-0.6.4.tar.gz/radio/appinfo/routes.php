<?php


/** @var $this \OCP\Route\IRouter */
$this->create('radio_index', '/')
	->actionInclude('radio/index.php');

return [
    'resources' => [
        'station' => ['url' => '/stations'],
        'station_api' => ['url' => '/api/0.1/stations']
    ],
    'routes' => [
        ['name' => 'page#index', 'url' => '/', 'verb' => 'GET'],
				['name' => 'page#favorites', 'url' => '/', 'verb' => 'GET'],
				['name' => 'page#recent', 'url' => '/', 'verb' => 'GET'],
				['name' => 'page#categories', 'url' => '/', 'verb' => 'GET'],
				['name' => 'page#top', 'url' => '/', 'verb' => 'GET'],
				['name' => 'settings#getMenuState', 'url' => '/getMenuState', 'verb' => 'GET'],
				['name' => 'settings#getVolumeState', 'url' => '/getVolumeState', 'verb' => 'GET'],
				['name' => 'settings#saveMenuState', 'url' => '/saveMenuState', 'verb' => 'POST'],
				['name' => 'settings#saveVolumeState', 'url' => '/saveVolumeState', 'verb' => 'POST'],
        ['name' => 'station_api#preflighted_cors', 'url' => '/api/0.1/{path}',
         'verb' => 'OPTIONS', 'requirements' => ['path' => '.+']]
    ]
];
