<?php

namespace OCA\Radio\Controller;

use \OCP\AppFramework\Controller;
use \OCP\AppFramework\Http\TemplateResponse;
use \OCP\IRequest;
use \OCA\Radio\Service\ConfigService;

class SettingsController extends Controller {

	private $userId;
	private $appConfig;

	public function __construct($appName, IRequest $request, ConfigService $appConfig, $userId) {
		parent::__construct($appName, $request);
		$this->userId = $userId;
		$this->appConfig = $appConfig;
	}

  /**
	 * Save order for current user
	 *
	 * @NoAdminRequired
	 * @return array response
	 */
	public function getMenuState() {
		$menu_state = $this->appConfig->getUserValue('menu_state', $this->userId);
		$response = array(
			'status' => 'success',
			'data' => array('message' => 'User order saved successfully.'),
			'menu_state' => $menu_state
		);
		return $response;
	}

	/**
	 * Save order for current user
	 *
	 * @NoAdminRequired
	 * @param $menu_state string
	 * @return array response
	 */
	public function saveMenuState($menu_state) {
		$this->appConfig->setUserValue('menu_state', $this->userId, $menu_state);
		$response = array(
			'status' => 'success',
			'data' => array('message' => 'User order saved successfully.'),
			'menu_state' => $menu_state
		);
		return $response;
	}

	/**
	 * Save volume for current user
	 *
	 * @NoAdminRequired
	 * @return array response
	 */
	public function getVolumeState() {
		$volume_state = $this->appConfig->getUserValue('volume_state', $this->userId);
		$response = array(
			'status' => 'success',
			'data' => array('message' => 'User volume saved successfully.'),
			'volume_state' => $volume_state
		);
		return $response;
	}

	/**
	 * Save volume for current user
	 *
	 * @NoAdminRequired
	 * @param $menu_state string
	 * @return array response
	 */
	public function saveVolumeState($volume_state) {
		$this->appConfig->setUserValue('volume_state', $this->userId, $volume_state);
		$response = array(
			'status' => 'success',
			'data' => array('message' => 'User volume saved successfully.'),
			'volume_state' => $volume_state
		);
		return $response;
	}

}
