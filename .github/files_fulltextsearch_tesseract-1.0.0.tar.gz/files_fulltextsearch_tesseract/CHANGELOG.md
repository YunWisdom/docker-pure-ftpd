# Changelog


### 1.0.0

First stable release


### 0.2.0

compat fts 0.99.1 - getting IndexDocument by events


### 0.1.0

First commit
