OC.L10N.register(
    "files_fulltextsearch",
    {
    "Go to folder" : "Siirry kansioon",
    "Open folder" : "Avaa kansio",
    "Name" : "Nimi",
    "Modified" : "Muokattu",
    "Size" : "Koko",
    "Could not copy \"{file}\"" : "Ei voitu kopioida tiedostoa \"{file}\"",
    "Full text search - Files" : "Koko tekstin haku - Tiedostot",
    "Index the content of your files" : "Indeksoi tiedostojesi sisältö",
    "Files" : "Tiedostot",
    "Sources" : "Lähteet",
    "Local Files" : "Paikalliset tiedostot",
    "Types" : "Tyypit",
    "Maximum file size" : "Tiedoston enimmäiskoko",
    "Maximum file size to index (in Mb)." : "Indeksoitavien tiedostojen enimmäiskoko (megabiteissä).",
    "Extract PDF" : "Pura PDF",
    "Index the content of PDF files." : "Indeksoi PDF-tiedostojen sisältö.",
    "Extract Office" : "Pura Office",
    "Index the content of office files." : "Indeksoi Office-tiedostojen sisältö."
},
"nplurals=2; plural=(n != 1);");
