OC.L10N.register(
    "files_fulltextsearch",
    {
    "Go to folder" : "前往資料夾",
    "Open folder" : "開啟資料夾",
    "Name" : "名稱",
    "Modified" : "已修改",
    "Size" : "大小",
    "Could not copy \"{file}\", target exists" : "無法複製\"{file}\"，目標已存在",
    "Could not copy \"{file}\"" : "無法複製\"{file}\"",
    "Copied {origin} inside {destination}" : "已複製 {origin} 至 {destination}",
    "Full text search - Files" : "全文搜尋 - 檔案",
    "Files" : "檔案"
},
"nplurals=1; plural=0;");
