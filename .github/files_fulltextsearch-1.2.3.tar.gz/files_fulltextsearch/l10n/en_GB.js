OC.L10N.register(
    "files_fulltextsearch",
    {
    "Go to folder" : "Go to folder",
    "Open folder" : "Open folder",
    "Name" : "Name",
    "Modified" : "Modified",
    "Size" : "Size",
    "Could not copy \"{file}\", target exists" : "Could not copy \"{file}\", target exists",
    "Could not copy \"{file}\"" : "Could not copy \"{file}\"",
    "Copied {origin} inside {destination}" : "Copied {origin} inside {destination}",
    "Copied {origin} and {nbfiles} other files inside {destination}" : "Copied {origin} and {nbfiles} other files inside {destination}",
    "Index the content of your files" : "Index the content of your files",
    "Extension to the _Full text search_ app to index your users' files." : "Extension to the _Full text search_ app to index your users' files.",
    "Files" : "Files"
},
"nplurals=2; plural=(n != 1);");
