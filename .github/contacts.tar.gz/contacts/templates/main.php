<?php
script('contacts', 'contacts');
style('contacts', 'contacts');
?>
