OC.L10N.register(
    "mood",
    {
    "New mood" : "Nieuwe stemming",
    "Share with ..." : "Delen met ...",
    "Share your mood" : "Deel je stemming",
    "{author} shared a mood with you" : "{author} deelde een stemming met jou",
    "{author} shared a mood with {circles}" : "{author} deelde een stemming met {circles}",
    "You shared a mood with {circles}" : "Je deelde een stemming met {circles}",
    "A social <strong>mood</strong> is shared" : "Een sociale <strong>stemming</strong> is gedeeld",
    "mood" : "stemming",
    "Your mood over the clouds" : "Je stemming in de clouds"
},
"nplurals=2; plural=(n != 1);");
