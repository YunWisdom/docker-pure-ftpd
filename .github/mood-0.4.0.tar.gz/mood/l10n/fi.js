OC.L10N.register(
    "mood",
    {
    "New mood" : "Uusi mielentila",
    "Share with ..." : "Jaa...",
    "Share your mood" : "Jaa mielentilasi",
    "{author} shared a mood with you" : "{author} jakoi mielentilansa kanssasi",
    "Your mood over the clouds" : "Mielentilasi pilvien yläpuolella"
},
"nplurals=2; plural=(n != 1);");
