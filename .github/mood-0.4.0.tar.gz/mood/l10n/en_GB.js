OC.L10N.register(
    "mood",
    {
    "New mood" : "New mood",
    "Share with ..." : "Share with ...",
    "Share your mood" : "Share your mood",
    "{author} shared a mood with you" : "{author} shared a mood with you",
    "{author} shared a mood with {circles}" : "{author} shared a mood with {circles}",
    "You shared a mood with {circles}" : "You shared a mood with {circles}",
    "A social <strong>mood</strong> is shared" : "A social <strong>mood</strong> is shared",
    "mood" : "mood",
    "Your mood over the clouds" : "Your mood over the clouds",
    "**mood** use the **Activity** and **Circles** apps to make the perfect social media tool for your Nextcloud.\n\n💬 With **mood**, you can instantly share a short text with other users on your instance: it can be a status update, a link, an information or anything you want.\nYou don't have to share with everyone: thanks to the **Circles** app, you decide who can see your moods 🔒\n\nIf you want to connect with other instances, you can federate your Circles with them.\nLink your _circles_ with remote clouds and your messages will be broadcast all over the mesh!🚀" : "**mood** use the **Activity** and **Circles** apps to make the perfect social media tool for your Nextcloud.\n\n💬 With **mood**, you can instantly share a short text with other users on your instance: it can be a status update, a link, an information or anything you want.\nYou don't have to share with everyone: thanks to the **Circles** app, you decide who can see your moods 🔒\n\nIf you want to connect with other instances, you can federate your Circles with them.\nLink your _circles_ with remote clouds and your messages will be broadcast all over the mesh!🚀"
},
"nplurals=2; plural=(n != 1);");
