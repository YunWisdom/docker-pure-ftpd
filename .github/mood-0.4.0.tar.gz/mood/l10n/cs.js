OC.L10N.register(
    "mood",
    {
    "New mood" : "Nová nálada",
    "Share with ..." : "Sdílet s…",
    "Share your mood" : "Sdílejte svou náladu",
    "mood" : "nálada"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n >= 2 && n <= 4 && n % 1 == 0) ? 1: (n % 1 != 0 ) ? 2 : 3;");
