OC.L10N.register(
    "files_mindmap",
    {
        "New mind map file": "Nový súbor myšlienkovej mapy",
        "New mind map.km": "Nové mindmap.km",
        "Main Topic": "Hlavná téma",
        "Saving...": "Ukladá sa...",
        "This file is not a valid mind map file and may cause file corruption if you continue editing.": "Tento súbor nie je platným myšlienko-mapovým súborom, jeho úpravou ho môžete poškodiť",
        "Load file fail!": "Súbor sa nepodarilo načítať",
        "File Saved": "Súbor bol uložený",
        "Save failed": "Uloženie zlyhalo",
        "Export": "Exportovať",
        "Export to PNG": "Exportovať do formátu PNG",
        "Export to SVG": "Exportovať do formátu SVG"
    },"nplurals=1; plural=0;"
);