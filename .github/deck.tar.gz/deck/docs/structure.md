## Database structure

Deck stores most of its data inside of the database. The structure and relationships between entities is documented in the following ER diagram:

![Screenshot](resources/er-diagram.jpg)

