# Changelog


### 1.0.0

First stable release


### 0.99.1

- improvement: no more chunks


### 0.7.0

- compat fulltextsearch 0.7.0 and fulltextsearch navigation app.



### Beta 0.1.0

- First Beta

