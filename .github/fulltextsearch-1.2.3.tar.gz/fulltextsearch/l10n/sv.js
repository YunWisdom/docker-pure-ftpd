OC.L10N.register(
    "fulltextsearch",
    {
    "Search" : "Sök",
    "Full text search" : "Fulltextsökning",
    "Index not found" : "Index hittades inte",
    "Search on %s" : "Sök på %s",
    "General" : "Allmänt",
    "Search Platform" : "Sökplattform",
    "Select the app to index content and answer search queries." : "Välj app för att indexera innehåll och svara på sökfrågor.",
    "Navigation Icon" : "Navigations-ikon",
    "Enable global search within all your content." : "Aktivera global sökning för all din data."
},
"nplurals=2; plural=(n != 1);");
