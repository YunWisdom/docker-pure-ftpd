OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "Búsqueda de texto completo",
    "Index not found" : "No se encontró el índice",
    "Tick not found" : "Marca no encontrada",
    "Core of the full-text search framework for Nextcloud" : "Núcleo del marco de trabajo de la búsqueda por texto completo para Nextcloud",
    "Core App of the full-text search framework for your Nextcloud." : "Aplicación núcleo del marco de trabajo de la búsqueda por texto completo para Nextcloud",
    "Search on %s" : "Busar en %s",
    "General" : "General"
},
"nplurals=2; plural=(n != 1);");
