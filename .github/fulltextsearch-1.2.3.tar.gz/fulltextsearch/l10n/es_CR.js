OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "Búsqueda de texto completo",
    "Index not found" : "No se encontró el índice",
    "Tick not found" : "Marca no encontrada",
    "Search on %s" : "Busar en %s",
    "General" : "General"
},
"nplurals=2; plural=(n != 1);");
