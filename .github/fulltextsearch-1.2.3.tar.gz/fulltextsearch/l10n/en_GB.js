OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "Full text search",
    "Index not found" : "Index not found",
    "Tick not found" : "Tick not found",
    "Core of the full-text search framework for Nextcloud" : "Core of the full-text search framework for Nextcloud",
    "Core App of the full-text search framework for your Nextcloud." : "Core App of the full-text search framework for your Nextcloud.",
    "Search on %s" : "Search on %s",
    "General" : "General"
},
"nplurals=2; plural=(n != 1);");
