OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "جستجوی کامل متن",
    "Index not found" : "نمایه یافت نشد",
    "Tick not found" : "تیک یافت نشد",
    "Search on %s" : "%s جستجو در ‍"
},
"nplurals=2; plural=(n > 1);");
