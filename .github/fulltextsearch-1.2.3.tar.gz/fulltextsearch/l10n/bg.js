OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "Пълно текстово търсене",
    "Index not found" : "Няма открито съдържание",
    "Search on %s" : "Търси в %s",
    "General" : "Общи"
},
"nplurals=2; plural=(n != 1);");
