OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "Testu osoko bilaketa",
    "Index not found" : "Indizea ez da aurkitu",
    "Tick not found" : "Marka ez da aurkitu",
    "Search on %s" : "Bilatu %s-(e)an"
},
"nplurals=2; plural=(n != 1);");
