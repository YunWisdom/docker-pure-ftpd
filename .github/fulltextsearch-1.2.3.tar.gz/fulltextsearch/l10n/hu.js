OC.L10N.register(
    "fulltextsearch",
    {
    "Search" : "Keresés",
    "Full text search" : "Teljes szöveges keresés",
    "Index not found" : "INdex nem található",
    "Tick not found" : "Vonás nem található",
    "Search on %s" : "Keresés itt: %s",
    "General" : "Általános",
    "Search Platform" : "Keresési platform",
    "Select the app to index content and answer search queries." : "Válassz ki az alkalmazást, ami rendezi a tartalmat és válaszol a keresési kérésekre.",
    "Navigation Icon" : "Navigációs Icon",
    "Enable global search within all your content." : "Teljes keresés engedélyezése az összes tartalomban."
},
"nplurals=2; plural=(n != 1);");
