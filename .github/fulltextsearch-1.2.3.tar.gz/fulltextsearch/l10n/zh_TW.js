OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "全文搜尋",
    "Index not found" : "找不到索引",
    "Tick not found" : "找不到 Tick",
    "Search on %s" : "在 %s 搜尋"
},
"nplurals=1; plural=0;");
