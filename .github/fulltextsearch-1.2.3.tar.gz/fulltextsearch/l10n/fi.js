OC.L10N.register(
    "fulltextsearch",
    {
    "Search" : "Haku",
    "Full text search" : "Kokotekstihaku",
    "Index not found" : "Indeksiä ei löydy",
    "Search on %s" : "Etsi kohteesta %s",
    "General" : "Yleiset"
},
"nplurals=2; plural=(n != 1);");
