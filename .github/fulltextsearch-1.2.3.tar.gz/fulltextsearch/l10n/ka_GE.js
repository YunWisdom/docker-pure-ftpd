OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "სრული ტექსტის ძიება",
    "Index not found" : "ინდექსი ვერ იქნა ნაპოვნი",
    "Tick not found" : "Tick ვერ იქნა ნაპოვნი",
    "Search on %s" : "ძიება %s-ზე"
},
"nplurals=2; plural=(n!=1);");
