OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "Fuld tekst søgning",
    "Index not found" : "Index ikke fundet",
    "Tick not found" : "Kryds ikke fundet",
    "Search on %s" : "Søg på %s"
},
"nplurals=2; plural=(n != 1);");
