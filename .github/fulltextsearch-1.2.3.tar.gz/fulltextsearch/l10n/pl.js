OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "Wyszukiwanie pełnotekstowe",
    "Index not found" : "Nie znaleziono indeksu",
    "Tick not found" : "Nie znaleziono znacznika",
    "Core of the full-text search framework for Nextcloud" : "Podstawa systemu wyszukiwania pełnotekstowego dla Nextcloud",
    "Core App of the full-text search framework for your Nextcloud." : "Podstawowa aplikacja systemu wyszukiwania pełnotekstowego dla Nextcloud",
    "Search on %s" : "Szukaj w %s",
    "General" : "Ogólne"
},
"nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);");
