OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "Fulltekst søk",
    "Index not found" : "Indeks ble ikke funnet",
    "Search on %s" : "Søk etter %s",
    "General" : "Generelt"
},
"nplurals=2; plural=(n != 1);");
