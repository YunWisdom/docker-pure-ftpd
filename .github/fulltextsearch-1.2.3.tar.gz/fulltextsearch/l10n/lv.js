OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "Pilna teksta meklēšana",
    "Index not found" : "Indekss netika atrasts",
    "Tick not found" : "Atzīme netika atrasta",
    "Core of the full-text search framework for Nextcloud" : "Kodols pilna teksta meklēšanas satvars priekš Nextcloud",
    "Core App of the full-text search framework for your Nextcloud." : "Kodola lietotne priekš pilna teksta meklēšanas satvara tavā Nextcloud.",
    "Search on %s" : "Meklēt %s",
    "General" : "Vispārīgs"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
