OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "חיפוש טקסט מלא",
    "Index not found" : "המפתח לא נמצא",
    "Core of the full-text search framework for Nextcloud" : "ליבת סביבת עבודת חיפוש טקסט מלא עבור Nextcloud",
    "Core App of the full-text search framework for your Nextcloud." : "יישומון ליבה של סביבת עבודה לחיפוש טקסט מלא עבור ה־Nextcloud שלך.",
    "Search on %s" : "חיפוש תחת %s",
    "General" : "כללי"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: (n % 10 == 0 && n % 1 == 0 && n > 10) ? 2 : 3;");
