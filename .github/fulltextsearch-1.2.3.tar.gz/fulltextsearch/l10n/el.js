OC.L10N.register(
    "fulltextsearch",
    {
    "Full text search" : "Πλήρης αναζήτηση κειμένου",
    "Index not found" : "Δεν βρέθηκε ευρετήριο",
    "Tick not found" : "Η σημείωση δεν βρέθηκε",
    "Search on %s" : "Αναζήτηση στο %s",
    "General" : "Γενικά"
},
"nplurals=2; plural=(n != 1);");
