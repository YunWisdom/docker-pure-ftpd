<?php
print '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
?>
<root>
	<error code='<?php p($_['code']); ?>'><?php p($_['message']); ?></error>
</root>
