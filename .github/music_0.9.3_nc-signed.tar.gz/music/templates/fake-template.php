<!--  this template is just a fake template it's purpose is to get fetched
while extraction, because this string is located in PHP code -->
<span translate>Music</span>
<span translate>Unknown album</span>
<span translate>Unknown artist</span>
<span translate>Artists</span>
<span translate>Albums</span>
<span translate>Tracks</span>

<!-- localizations for files-music-plalyer -->
<span translate>Loading…</span>
<span translate>Close</span>
<span translate>Go to album</span>
<span translate>(file is not within your music collection folder)</span>
