OC.L10N.register(
    "music",
    {
    "Music" : "ਸੰਗੀਤ"
},
"nplurals=2; plural=(n != 1);");
