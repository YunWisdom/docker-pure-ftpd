OC.L10N.register(
    "music",
    {
    "Albums" : "Albumai",
    "Artists" : "Atlikėjai",
    "Description" : "Aprašymas",
    "Generate API password" : "Sugeneruoti API slaptažodį",
    "Invalid path" : "Netinkamas kelias",
    "Music" : "Muzika",
    "Next" : "Kitas",
    "Pause" : "Pristabdyti",
    "Play" : "Groti",
    "Previous" : "Ankstesnis",
    "Repeat" : "Kartoti",
    "Shuffle" : "Maišyti",
    "Unknown album" : "Nežinomas albumas",
    "Unknown artist" : "Nežinomas atlikėjas"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && (n%100<10 || n%100>=20) ? 1 : 2);");
