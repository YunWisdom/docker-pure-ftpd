OC.L10N.register(
    "music",
    {
    "Next" : "ಮುಂದೆ"
},
"nplurals=1; plural=0;");
