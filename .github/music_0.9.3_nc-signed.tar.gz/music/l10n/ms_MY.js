OC.L10N.register(
    "music",
    {
    "Description" : "Keterangan",
    "Music" : "Muzik",
    "Next" : "Seterus",
    "Pause" : "Jeda",
    "Play" : "Main",
    "Previous" : "Sebelum",
    "Repeat" : "Ulang",
    "Shuffle" : "Kocok"
},
"nplurals=1; plural=0;");
