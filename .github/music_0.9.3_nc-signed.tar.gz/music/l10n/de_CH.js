OC.L10N.register(
    "music",
    {
    "Description" : "Beschreibung",
    "Music" : "Musik",
    "Next" : "Weiter",
    "Pause" : "Anhalten",
    "Play" : "Abspielen",
    "Previous" : "Vorheriges",
    "Repeat" : "Wiederholen"
},
"nplurals=2; plural=(n != 1);");
