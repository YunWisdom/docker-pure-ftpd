OC.L10N.register(
    "music",
    {
    "Next" : "Nächtes",
    "Pause" : "Pause",
    "Play" : "Play",
    "Previous" : "Vorheriges"
},
"nplurals=2; plural=(n != 1);");
