OC.L10N.register(
    "music",
    {
    "Albums" : "Ալբոմներ",
    "Artists" : "Արտիստներ",
    "Description" : "Նկարագրություն",
    "Description (e.g. App name)" : "Նկարագրություն (օր.՝ App name)",
    "Generate API password" : "Գեներացնել API գաղտնաբառ",
    "Invalid path" : "Անվավեր ուղի",
    "Music" : "Երաժշտություն",
    "Next" : "Հաջորդ",
    "Path to your music collection" : "Քո երաժշտական հավաքածուի ուղին",
    "Play" : "Նվագարկել",
    "Previous" : "Նախորդ",
    "Repeat" : "Կրկնել",
    "Shuffle" : "Խառը",
    "Unknown album" : "Անհայտ ալբոմ",
    "Unknown artist" : "Անհայտ հեղինակ"
},
"nplurals=2; plural=(n != 1);");
