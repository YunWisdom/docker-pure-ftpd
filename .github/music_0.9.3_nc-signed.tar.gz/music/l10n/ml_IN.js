OC.L10N.register(
    "music",
    {
    "Music" : "സംഗീതം",
    "Next" : "അടുത്തത്",
    "Pause" : " നിറുത്ത്",
    "Play" : "തുടങ്ങുക",
    "Previous" : "മുന്‍പത്തേത്"
},
"nplurals=2; plural=(n != 1);");
