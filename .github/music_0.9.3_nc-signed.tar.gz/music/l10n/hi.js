OC.L10N.register(
    "music",
    {
    "Albums" : "एलबम",
    "Artists" : "कलाकारों",
    "Description" : "विवरण",
    "Music" : "गाना",
    "Next" : "अगला"
},
"nplurals=2; plural=(n != 1);");
