OC.L10N.register(
    "music",
    {
    "Description" : "გვერდის დახასიათება",
    "Music" : "მუსიკა",
    "Next" : "შემდეგი",
    "Pause" : "პაუზა",
    "Play" : "დაკვრა",
    "Previous" : "წინა",
    "Repeat" : "გამეორება"
},
"nplurals=1; plural=0;");
