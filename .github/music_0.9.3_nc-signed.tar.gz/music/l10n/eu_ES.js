OC.L10N.register(
    "music",
    {
    "Description" : "Deskripzioa",
    "Music" : "Musika",
    "Next" : "Aurrera",
    "Pause" : "geldi",
    "Play" : "jolastu",
    "Previous" : "Atzera",
    "Repeat" : "Errepikatu"
},
"nplurals=2; plural=(n != 1);");
