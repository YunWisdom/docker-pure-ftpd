OC.L10N.register(
    "music",
    {
    "Description" : "پێناسه",
    "Music" : "مۆسیقا",
    "Next" : "دوواتر",
    "Pause" : "وه‌ستان",
    "Play" : "لێدان",
    "Previous" : "پێشووتر"
},
"nplurals=2; plural=(n != 1);");
