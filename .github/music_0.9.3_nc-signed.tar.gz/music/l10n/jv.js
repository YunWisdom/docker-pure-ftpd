OC.L10N.register(
    "music",
    {
    "Music" : "Gamelan",
    "Next" : "Sak bare",
    "Play" : "Puter",
    "Previous" : "Sak durunge"
},
"nplurals=2; plural=(n != 1);");
