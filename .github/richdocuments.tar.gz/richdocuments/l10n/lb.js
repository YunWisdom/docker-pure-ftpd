OC.L10N.register(
    "richdocuments",
    {
    "Save" : "Späicheren",
    "Edit" : "Änneren",
    "Could not create file" : "De Fichier konnt net erstallt ginn",
    "Can't create document" : "D'Dokument kann net erstallt ginn",
    "New Document.odt" : "Neit Dokument.odt",
    "New Spreadsheet.ods" : "Neien Spreadsheet.ods",
    "New Presentation.odp" : "Nei Presentatioun.odp",
    "Saved" : "Gespäichert",
    "Collabora Online" : "Collabora Online",
    "Collabora Online server" : "Collabora Online Server",
    "URL (and port) of the Collabora Online server that provides the editing functionality as a WOPI client." : "D'URL (an de Port) vum Collabora Online Server, déi d'Editing Funktioun als WOPI Client liwwert.",
    "Apply" : "Uwenden",
    "Wrong password. Please retry." : "Falscht Passwuert. W.e.g. probéier nach eemol.",
    "Password" : "Passwuert",
    "OK" : "OK",
    "Guest %s" : "Gaascht %s",
    "This link has been expired or is never existed. Please contact the person who shared it with you for details." : "Dëse Link ass ofgelaf oder huet ni existéiert. W.e.g. kontaktéier d'Persoun déi en mat der gedeelt huet fir Detailer."
},
"nplurals=2; plural=(n != 1);");
