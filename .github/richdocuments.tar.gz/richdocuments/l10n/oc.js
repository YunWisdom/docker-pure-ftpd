OC.L10N.register(
    "richdocuments",
    {
    "Save" : "Enregistrar",
    "Edit" : "Modificar",
    "Could not create file" : "Impossible de crear lo fichièr",
    "Can't create document" : "Impossible de crear lo document",
    "New Document.odt" : "Document Novèl.odt",
    "Saved" : "Enregistrat",
    "Collabora Online" : "Collabora en linha",
    "Collabora Online server" : "Servidor Collabora en linha",
    "Apply" : "Aplicar",
    "Wrong password. Please retry." : "Senhal erronèu. Mercé de tornar ensajar.",
    "Password" : "Senhal",
    "OK" : "D'acòrdi",
    "Guest %s" : "Convidat %s",
    "This link has been expired or is never existed. Please contact the person who shared it with you for details." : "Aqueste ligam a expirat o a pas jamai existit. Per mai de detalhs, contactatz la persona qu'a partejat aqueste ligam amb vos."
},
"nplurals=2; plural=(n > 1);");
