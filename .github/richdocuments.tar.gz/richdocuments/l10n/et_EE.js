OC.L10N.register(
    "richdocuments",
    {
    "Saving…" : "Salvestamine...",
    "All" : "Kõik",
    "Save" : "Salvesta",
    "Edit" : "Muuda",
    "Could not create file" : "Ei suuda luua faili",
    "Can't create document" : "Ei suuda dokumenti luua",
    "New Presentation.pptx" : "Uus esitlus.pptx",
    "Saved" : "Salvestatud",
    "Apply" : "Rakenda",
    "Wrong password. Please retry." : "Vale parool. Palun proovi uuesti.",
    "Password" : "Parool",
    "OK" : "OK",
    "Guest %s" : "Külaline %s",
    "This link has been expired or is never existed. Please contact the person who shared it with you for details." : "See link on aegunud või seda pole kunagi eksisteerinud. Palun võta ühendust inimesega, kes selle sulle jagas."
},
"nplurals=2; plural=(n != 1);");
