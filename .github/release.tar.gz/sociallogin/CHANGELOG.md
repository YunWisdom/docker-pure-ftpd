
## 1.11.2
- Changed nextcloud max-version to 15

## 1.11.1
- Do not pass empty auth params

## 1.11.0
- Bump v.1.11.0
- Allow login only from specified domain for google provider
- Changed confirm delete provider text
- Provider icons in admin settings page
- Another workaround for custom oauth2
- add german translation
- Added missed comma in fr translation

## 1.10.1
- Fixed removing last custom provider
- Update zh_TW.json
- Update fr.json
- Update README.md

## 1.10.0
- Some tweaks for prevent_create_email_exists
- Added admin setting for enabling/disabling preventing creating account if email exists
- prevent creating account if email exists

## 1.9.5
- Fix social_login_auto_redirect for cli

## 1.9.4
- Merge branch 'master' of github.com:zorn-v/nextcloud-social-login
- Fixed custom oauth workaround
- Update README.md

## 1.9.3
- Bump version
- Merge branch 'master' of github.com:zorn-v/nextcloud-social-login
- Workaround for custom oauth id

## 1.9.2
- Bump v1.9.2
- Update zh_TW.json
- Update zh_TW.js
- Update zh_TW.json

## 1.9.1
- Check that custom providers is array before save admin settings
- Refactored render personal settings

## 1.9.0
- Some refactoring
- Fixes for custom oauth2
- Merge pull request #37 from portrino/custom-oauth2-provider
- Renamed query param redirect_url to login_redirect_url
- Use nexcloud session for hybridauth storage
- Added `@UseSession` annotations
- Redirect to redirect_url if provided
- [FEATURE] adds the possibility to use a custom oauth2 provider
- Merge branch 'master' of github.com:zorn-v/nextcloud-social-login
- Try to implement client login flow

## 1.8.1
- Use md5 of profileId if uid longer 64 chars
- Fixed notices if user_info_url provided

## 1.8.0
- Implemented user info endpoint
- Fixed typos
- Make all texts in admin settings page translatable
- Fields in settings template for oidc user info endpoint

## 1.7.1
- Fixed exception after creating user

## 1.7.0
- Minor fix in release script
- Set last password confirm on login
- Save personal settings
- Fixed chinese translation
- Disable password confirmation for users created via social login
- Personal option for disable password confirmation on settings change
- Check allow_login_connect setting in login controller

## 1.6.5
- Updated version
- add traditional Chinese translation
- add traditional Chinese translation
- Hints about credentials in release script
- Checkout to master before release

## 1.6.4
- Generate CHANGELOG.md on release
- Updated app info
- Removed unnecessary queries in each request

## 1.6.3
- Fix facebook scope
- Refactored login controller

## 1.6.2
- Check for name of all providers for duplicate on save

## 1.6.1
- Alignment fix

## 1.6.0
- Icons for oauth providers

## 1.5.5
- Added Discord provider

## 1.5.4
- Fixed "undefined index: password" in error log

## 1.5.3
- Updated version
- Merge pull request #14 from thomas-lb/french-translation
- Merge pull request #13 from thomas-lb/issue-12
- Add French translation
- Replace title and name providers (fixes #12)

## 1.5.2
- Proper handling providers name and title
- Repair step for separate user configured providers internal name and title
- Universal release script

## 1.5.1
- updated version
- Removed already unnecessary hybridauth fixes
- Updated hybridauth to 3.0.0-rc.5
- Fixed unknown provider translation
- Check for oauth provider existence
- Improved release script

## 1.5.0
- social_login_auto_redirect in config.php
- Merge pull request #8 from sutoiku/master

## 1.4.1
- Clickable links for nexcloud app store description
- Merge remote-tracking branch 'upstream/master'
- Allow automatic redirection if only one alternative login

## 1.4.0
- Check providers titles before saving
- Some minor fixes
- Merge pull request #6 from sutoiku/master
- Remove authenticate override
- Merge remote-tracking branch 'upstream/master'
- Added github link in readme
- Merge remote-tracking branch 'upstream/master'
- Rename to OpenIdConnect

## 1.3.5
- Insert README.md in info.xml description on release
- Get profile from id_token attribute
- Change "oauth2" to "custom_oauth"
- Throw LoginException on empty identifier from provider
- Implement custom OAuth2 login
- Save oauth2 settings
- Add admin settings

## 1.3.4
- Check all saved providers settings before using

## 1.3.3
- Prevent log flood with invalid app config values
- Updated version
- Merge pull request #4 from JanGross/master
- Fix invalid argument if no OpenID providers present

## 1.3.1
- Fixed database.xml

## 1.3.0
- Remove connected social logins on user delete
- Posibility to disconnect connected logins
- Connect social login to account
- List of avail providers on personal settings page
- Render personal settings page
- Allow login connect setting
- DAO for connect logins
- Create table for connect logins
- Translated login exceptions
- Basic check for connect social login to exsisting account
- Disable auto create new users setting
- LoginException on unknown OpenID provider

## 1.2.4
- Fixed issues in admin settings
- Login without password
- Throw LoginException on login error

## 1.2.3
- Updated version
- Extended OpenID provider

## 1.2.2
- Updated version
- Generate forgotten uid

## 1.2.1
- Fix OpenID auth

## 1.2.0
- Try to login via generic OpenID provider
- Renamed login controller
- Adding openid providers
- Remove openid provider button
- Removed preconfigured open id providers

## 1.1.0
- Updated version
- PaypalOpenID support

## 1.0.2
- Default value for oauth providers setting

## 1.0.1
- Fix log error while no providers configured
- Script for make release
- Added max version

## 1.0.0
- Updated version
- Tip about redirect url
- Updated README
- Added twitter provider
- Added GitHub provider
- Listen for password change
- Set email address for new user
- Added screenshot to info.xml
- Added screenshot
- Adding new user to default group
- Set avatar for new user
- Updated readme
- Update version
- Save password in user config
- Login with new created user
- Create new user
- Fixed session issue
- Custom session storage
- Changed oauth login url
- Try to auth
- Refactored oauth providers settings
- Settings for facebook and google
- New user group setting
- Init
