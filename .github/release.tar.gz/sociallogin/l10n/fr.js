OC.L10N.register(
  "sociallogin",
  {
    "Settings for social login successfully saved": "Paramètres sauvegardés avec succès",
    "Do you realy want to remove {providerTitle} provider ?": "Voulez-vous vraiment supprimer fournisseur {providerTitle} ?",
    "Some error occurred while saving settings": "Erreur lors de la sauvegarde des paramètres",
    "Confirm remove": "Confirmer la suppression"
  },
"nplurals=2; plural=(n > 1);");
