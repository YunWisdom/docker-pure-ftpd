OC.L10N.register(
  "sociallogin",
  {
    "Settings for social login successfully saved": "Die Einstellungen für Social Login wurden erfolgreich gespeichert",
    "Do you realy want to remove {providerTitle} provider ?": "Möchten Sie den Provider {providerTitle} wirklich entfernen?",
    "Some error occurred while saving settings": "Es trat ein Fehler beim Speichern der Einstellungen auf",
    "Confirm remove": "Entfernen bestätigen"
  },
"nplurals=2; plural=(n > 1);");
