OC.L10N.register(
  "sociallogin",
  {
    "Settings for social login successfully saved": "儲存成功",
    "Do you realy want to remove {providerTitle} provider ?": "你真的想刪除這個{providerTitle}項目嗎？",
    "Some error occurred while saving settings": "儲存設定時發生了錯誤",
    "Confirm remove": "確定刪除"
  },
"nplurals=1; plural=0;");
