<?php

require __DIR__ . '/../3rdparty/autoload.php';

$app = new \OCA\SocialLogin\AppInfo\Application();
$app->register();
