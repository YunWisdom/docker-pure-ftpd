Hybridauth ChangeLog
====================

3.1.0 - TBD
    ...

3.0.0 - TBD

## Upgrading from 2.x
TODO