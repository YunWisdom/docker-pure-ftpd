/*!
 * ojsxc v3.4.3 - 2018-12-05
 * 
 * Copyright (c) 2018 Klaus Herberth <klaus@jsxc.org> <br>
 * Released under the MIT license
 * 
 * Please see http://www.jsxc.org/
 * 
 * @author Klaus Herberth <klaus@jsxc.org>
 * @version 3.4.3
 * @license MIT
 */

/**
 * This is a helper file for the concatenation.
 */
;
