<?php

namespace OCA\OJSXC\Exceptions;

// TODO
class TerminateException extends Exception
{
}
