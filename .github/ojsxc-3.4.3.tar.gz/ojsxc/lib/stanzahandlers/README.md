#lib/stanzahandlers

This are the objects which handle incoming stanza's. The classess are called
by the `HTTPBindController` controller.

