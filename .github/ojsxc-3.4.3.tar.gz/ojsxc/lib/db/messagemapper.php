<?php

namespace OCA\OJSXC\Db;

/**
 * Class MessageMapper
 *
 * @package OCA\OJSXC\Db
 */
class MessageMapper extends StanzaMapper
{
}
