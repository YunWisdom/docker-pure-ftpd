<?php

namespace OCA\OJSXC\Db;

/**
 * Class IQRosterPushMapper
 *
 * @package OCA\OJSXC\Db
 */
class IQRosterPushMapper extends StanzaMapper
{
}
