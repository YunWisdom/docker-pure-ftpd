<?php
$TRANSLATIONS = array(
"Saved" => "সংরক্ষিত",
"Saving..." => "সংরক্ষণ করা হচ্ছে ...",
"Share" => "শেয়ার",
"Save" => "সেভ",
"Cancel" => "বাতিল করা",
"Close" => "বন্ধ",
"Delete" => "মুছে ফেলা",
"Open" => "খোলা",
"Size" => "আকার",
"Edit" => "এডিট"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
