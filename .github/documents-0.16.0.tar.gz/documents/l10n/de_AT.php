<?php
$TRANSLATIONS = array(
"Share" => "Freigeben",
"Save" => "Speichern",
"Cancel" => "Abbrechen",
"Delete" => "Löschen",
"Edit" => "Bearbeiten",
"Password" => "Passwort"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
