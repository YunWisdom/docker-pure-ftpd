<?php
$TRANSLATIONS = array(
"Saving..." => "محفوظ ھو رہا ہے ...",
"Share" => "تقسیم",
"Save" => "حفظ",
"Cancel" => "منسوخ کریں",
"Close" => "بند ",
"Delete" => "حذف کریں",
"OK" => "اوکے",
"Open" => "کھولیں",
"Edit" => "تدوین کریں",
"Password" => "پاسورڈ"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
