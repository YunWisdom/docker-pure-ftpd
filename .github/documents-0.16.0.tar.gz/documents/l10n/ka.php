<?php
$TRANSLATIONS = array(
"Password" => "პაროლი"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
