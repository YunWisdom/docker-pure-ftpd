<?php
$TRANSLATIONS = array(
"Saving..." => "සුරැකෙමින් පවතී...",
"Share" => "බෙදා හදා ගන්න",
"Save" => "සුරකින්න",
"Cancel" => "එපා",
"Close" => "වසන්න",
"Create" => "තනන්න",
"Delete" => "මකා දමන්න",
"OK" => "හරි",
"Open" => "විවෘත කරන්න",
"Options" => "විකල්පයන්",
"Size" => "ප්‍රමාණය",
"Text" => "පෙළ",
"Edit" => "සකසන්න",
"Upload" => "උඩුගත කරන්න",
"Password" => "මුර පදය"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
