<?php
$TRANSLATIONS = array(
"Save" => "Gorde",
"Cancel" => "Ezeztatu",
"Delete" => "Ezabatu",
"Edit" => "Aldatu"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
