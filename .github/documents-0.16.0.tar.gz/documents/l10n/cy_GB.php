<?php
$TRANSLATIONS = array(
"Saving..." => "Yn cadw...",
"Share" => "Rhannu",
"Save" => "Cadw",
"'.' is an invalid file name." => "Mae '.' yn enw ffeil annilys.",
"File name cannot be empty." => "Does dim hawl cael enw ffeil gwag.",
"Invalid name, '\\', '/', '<', '>', ':', '\"', '|', '?' and '*' are not allowed." => "Enw annilys, ni chaniateir, '\\', '/', '<', '>', ':', '\"', '|', '?' na '*'.",
"Cancel" => "Diddymu",
"Close" => "Cau",
"Delete" => "Dileu",
"OK" => "Iawn",
"Open" => "Agor",
"Size" => "Maint",
"Text" => "Testun",
"Edit" => "Golygu",
"Upload" => "Llwytho i fyny",
"Password" => "Cyfrinair"
);
$PLURAL_FORMS = "nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;";
