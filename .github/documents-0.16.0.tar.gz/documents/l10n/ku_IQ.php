<?php
$TRANSLATIONS = array(
"Saving..." => "پاشکه‌وتده‌کات...",
"Share" => "هاوبەشی کردن",
"Save" => "پاشکه‌وتکردن",
"Cancel" => "لابردن",
"Close" => "داخستن",
"OK" => "باشە",
"Open" => "کردنه‌وه",
"Edit" => "دەسکاریکردن",
"Upload" => "بارکردن",
"Password" => "وشەی تێپەربو"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
