<?php
$TRANSLATIONS = array(
"Save" => "Պահպանել",
"Close" => "Փակել",
"Delete" => "Ջնջել"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
