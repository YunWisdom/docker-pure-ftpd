<?php
$TRANSLATIONS = array(
"Saving..." => "Speicheren...",
"Share" => "Deelen",
"Save" => "Späicheren",
"Cancel" => "Ofbriechen",
"Close" => "Zoumaachen",
"Create" => "Erstellen",
"Delete" => "Läschen",
"Family" => "Famill",
"OK" => "OK",
"Open" => "Opmaachen",
"Size" => "Gréisst",
"Text" => "SMS",
"Edit" => "Editéieren",
"Upload" => "Eroplueden",
"Password" => "Passwuert"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
