<?php
$TRANSLATIONS = array(
"Saving..." => "Stoor...",
"Share" => "Deel",
"Cancel" => "Kanseleer",
"OK" => "OK",
"Password" => "Wagwoord"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
