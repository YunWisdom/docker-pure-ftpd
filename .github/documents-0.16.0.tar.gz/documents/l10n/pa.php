<?php
$TRANSLATIONS = array(
"Saving..." => "...ਸੰਭਾਲਿਆ ਜਾ ਰਿਹਾ ਹੈ",
"Share" => "ਸਾਂਝਾ ਕਰੋ",
"Cancel" => "ਰੱਦ ਕਰੋ",
"Delete" => "ਹਟਾਓ",
"OK" => "ਠੀਕ ਹੈ",
"Upload" => "ਅੱਪਲੋਡ",
"Password" => "ਪਾਸਵਰ"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
