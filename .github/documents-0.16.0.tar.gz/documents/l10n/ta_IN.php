<?php
$TRANSLATIONS = array(
"Upload" => "பதிவேற்று"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
