<?php
$TRANSLATIONS = array(
"Saving..." => "Simpan...",
"Share" => "Kongsi",
"Save" => "Simpan",
"Cancel" => "Batal",
"Close" => "Tutup",
"Create" => "Buat",
"Delete" => "Padam",
"OK" => "OK",
"Open" => "Buka",
"Size" => "Saiz",
"Text" => "Teks",
"Edit" => "Sunting",
"Upload" => "Muat naik",
"Password" => "Kata laluan"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
