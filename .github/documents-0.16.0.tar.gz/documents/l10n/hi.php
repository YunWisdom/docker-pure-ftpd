<?php
$TRANSLATIONS = array(
"Documents" => "दस्तावेज़ ",
"Failed to load documents." => "दस्तावेज़ लोड करने में असफल रहा।  ",
"Share" => "साझा करें",
"Save" => "सहेजें",
"Cancel" => "रद्द करें ",
"Close" => "बंद करें ",
"Open" => "खोलें",
"Upload" => "अपलोड ",
"Password" => "पासवर्ड",
"Advanced feature-set" => "उन्नत विशेषता-सेट ",
"(Unstable)" => "(अस्थायी) "
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
