<?php
$TRANSLATIONS = array(
"Saving..." => "შენახვა...",
"Share" => "გაზიარება",
"Save" => "შენახვა",
"'.' is an invalid file name." => "'.' არის დაუშვებელი ფაილის სახელი.",
"File name cannot be empty." => "ფაილის სახელი არ შეიძლება იყოს ცარიელი.",
"Invalid name, '\\', '/', '<', '>', ':', '\"', '|', '?' and '*' are not allowed." => "არადაშვებადი სახელი, '\\', '/', '<', '>', ':', '\"', '|', '?' და  '*' არ არის დაიშვებული.",
"Cancel" => "უარყოფა",
"Close" => "დახურვა",
"Create" => "შექმნა",
"Delete" => "წაშლა",
"Family" => "ოჯახი",
"Loading" => "ჩატვირთვა",
"OK" => "დიახ",
"Open" => "გახსნა",
"Options" => "ოფცია",
"Size" => "ზომა",
"Text" => "ტექსტი",
"Edit" => "რედაქტირება",
"Upload" => "ატვირთვა",
"Password" => "პაროლი"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
