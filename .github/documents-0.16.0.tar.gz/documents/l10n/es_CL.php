<?php
$TRANSLATIONS = array(
"Share" => "Compartir",
"Cancel" => "Cancelar",
"OK" => "OK",
"Upload" => "Subir",
"Password" => "Clave"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
