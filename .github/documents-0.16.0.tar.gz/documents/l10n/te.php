<?php
$TRANSLATIONS = array(
"Save" => "భద్రపరచు",
"Cancel" => "రద్దుచేయి",
"Close" => "మూసివేయి",
"Delete" => "తొలగించు",
"OK" => "సరే",
"Size" => "పరిమాణం",
"Password" => "సంకేతపదం"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
