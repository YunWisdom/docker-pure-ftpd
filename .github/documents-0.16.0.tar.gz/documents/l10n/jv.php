<?php
$TRANSLATIONS = array(
"Edit" => "Ngganti"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
