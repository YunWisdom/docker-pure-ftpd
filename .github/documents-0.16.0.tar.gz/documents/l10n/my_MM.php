<?php
$TRANSLATIONS = array(
"Cancel" => "ပယ်ဖျက်မည်",
"OK" => "အိုကေ",
"Text" => "စာသား",
"Password" => "စကားဝှက်"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
