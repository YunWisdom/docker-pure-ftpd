== wqy-microhei.ttc ==
License  : This font is licensed under Apache2.0 or GPLv3
               with font embedding exceptions (see Appendix B).
               Read LICENSE_Apache2.txt and LICENSE_GPLv3.txt for details


== GenBasB.ttf ==
== GenBasBI.ttf ==
== GenBasI.ttf =
== GenBasR.ttf ==
== Lohit-Devanagari.ttf ==
License: OFL

LinBiolinum_RB_G.ttf
LinBiolinum_R_G.ttf
LinBiolinum_RI_G.ttf
License: OFL / GPLv3

== LiberationMono-BoldItalic.ttf ==
== LiberationMono-Bold.ttf ==
== LiberationMono-Italic.ttf ==
== LiberationMono-Regular.ttf ==
== LiberationSans-BoldItalic.ttf ==
== LiberationSans-Bold.ttf ==
== LiberationSans-Italic.ttf ==
== LiberationSans-Regular.ttf ==
== LiberationSerif-BoldItalic.ttf ==
== LiberationSerif-Bold.ttf ==
== LiberationSerif-Italic.ttf ==
== LiberationSerif-Regular.ttf ==
License: Liberation

