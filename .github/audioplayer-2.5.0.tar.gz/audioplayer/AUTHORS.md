# Authors

* [Marcel Scherello](https://github.com/rello) <audioplayer@scherello.de> (project leader)

## Test and Support

* [Thomas Marx](https://github.com/xramsamoht) <xramsamoht@users.noreply.github.com> (collaborator)

## Contributors

* [Sebastian Döll](https://github.com/libasys) <sebastian@libasys.de> (initial work)
