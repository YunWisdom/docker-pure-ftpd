<a class="confirmation-default">
    <span class="icon-delete"></span>
    <span><?php p($l->t('Delete')); ?></span>
</a>
<a class="confirmation-abort icon-close" title="<?php p($l->t('Cancel')); ?>">
    <span></span>
</a>
<a class="confirmation-confirm icon-delete-white no-permission">
    <span class="countdown">33 &nbsp;</span>
</a>
