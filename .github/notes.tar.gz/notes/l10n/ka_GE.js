OC.L10N.register(
    "notes",
    {
    "Notes" : "ჩანაწერები",
    "New note" : "ახალი ჩანაწერი",
    "There are unsaved notes. Leaving the page will discard all changes!" : "არსებობს შეუნახავი ჩანაწერები. გვერდის დატოვება ყველა ცვლილებას უარყოფს!",
    "_%n word_::_%n words_" : ["%n სიტყვა","%n სიტყვა"],
    "No notes found" : "ჩანაწერები ვერ იქნა ნაპოვნი",
    "Delete note" : "ჩანაწერის გაუქმება",
    "Favorite" : "რჩეული",
    "The note has unsaved changes." : "ჩანაწერს გააჩნია არ-შენახული ცვლილებები.",
    "Click here to try again" : "ახლიდან საცდელად დააწკაპუნეთ აქ",
    "Saving failed!" : "შენახვა ვერ მოხერხდა!",
    "Note saved" : "ჩანაწერი შენახულია"
},
"nplurals=2; plural=(n!=1);");
