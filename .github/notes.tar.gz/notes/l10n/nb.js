OC.L10N.register(
    "notes",
    {
    "Notes" : "Notater",
    "New note" : "Nytt notat",
    "There are unsaved notes. Leaving the page will discard all changes!" : "Det finnes ulagrede notater. Å forlate siden vil forkaste alle endringer!",
    "_%n word_::_%n words_" : ["%n ord","%n ord"],
    "No notes found" : "Ingen notater funnet",
    "Delete note" : "Slett notat",
    "Favorite" : "Gjør til favoritt",
    "The note has unsaved changes." : "Notatet har ulagrede endringer.",
    "Click here to try again" : "Klikk her for å prøve igjen",
    "Saving failed!" : "Lagring mislyktes!",
    "Note saved" : "Notat lagret"
},
"nplurals=2; plural=(n != 1);");
