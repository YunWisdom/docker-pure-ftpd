OC.L10N.register(
    "notes",
    {
    "Notes" : "Notoj",
    "New note" : "Nova noto",
    "_%n word_::_%n words_" : ["%n vorto","%n vortoj"],
    "File error" : "Eraro pri dosiero",
    "Encryption Error" : "Eraro pri ĉifrado",
    "Error" : "Eraro",
    "No notes found" : "Neniu noto troviĝis ",
    "Delete note" : "Forigi noton",
    "Favorite" : "Favorato",
    "Note saved" : "Noto konservinta"
},
"nplurals=2; plural=(n != 1);");
