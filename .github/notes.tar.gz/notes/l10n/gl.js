OC.L10N.register(
    "notes",
    {
    "Notes" : "Notas",
    "New note" : "Nova nota",
    "There are unsaved notes. Leaving the page will discard all changes!" : "Hai notas sen gardar. Deixar a páxina descartará todos os cambios!",
    "_%n word_::_%n words_" : ["%n palabra","%n palabras"],
    "The last viewed note cannot be accessed. " : "Non pode acceder á última nota visualizada. ",
    "File error" : "Erro de ficheiro",
    "Encryption Error" : "Erro de cifrado",
    "Error" : "Erro",
    "No notes found" : "Non se atoparon notas",
    "Delete note" : "Eliminar nota",
    "Favorite" : "Favorito",
    "The note has unsaved changes." : "A nota contén cambios non gardados.",
    "Click here to try again" : "Fai click aquí para tentalo de novo",
    "Saving failed!" : "Fallou ao gardar!",
    "Note saved" : "Nota gardada"
},
"nplurals=2; plural=(n != 1);");
