OC.L10N.register(
    "workflow_pdf_converter",
    {
    "Mode…" : "Modo...",
    "Keep original, preserve existing PDFs" : "Manter o original, preservar PDFs existentes",
    "Keep original, overwrite existing PDF" : "Manter o original, substituir PDF",
    "Delete original, preserve existing PDFs" : "Apagar o original, manter PDFs existentes",
    "PDF conversion" : "Converter PDF"
},
"nplurals=2; plural=(n != 1);");
