OC.L10N.register(
    "workflow_pdf_converter",
    {
    "Mode…" : "Modua...",
    "Keep original, preserve existing PDFs" : "Mantendu jatorrizkoak eta gorde dauden PDFak",
    "Keep original, overwrite existing PDF" : "Mantendu jatorrizkoa eta gainidatzi dagoen PDFa",
    "Delete original, preserve existing PDFs" : "Ezabatu jatorrizko eta gorde dauden PDFak",
    "Delete original, overwrite existing PDF" : "Ezabatu jatorrizkoa, gainidatzi dagoen PDFa",
    "Please choose a mode." : "Hautatu modu bat",
    "PDF conversion" : "PDF bihurketa"
},
"nplurals=2; plural=(n != 1);");
