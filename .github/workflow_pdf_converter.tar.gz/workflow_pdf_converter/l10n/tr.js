OC.L10N.register(
    "workflow_pdf_converter",
    {
    "Mode…" : "Kip…",
    "Keep original, preserve existing PDFs" : "Özgün korunsun, var olan PDF belgeleri korunsun",
    "Keep original, overwrite existing PDF" : "Özgün korunsun, var olan PDF dosyaları üzerine yazılsın",
    "Delete original, preserve existing PDFs" : "Özgün silinsin, var olan PDF dosyaları korunsun",
    "Delete original, overwrite existing PDF" : "Özgün silinsin, var olan PDF dosyaları üzerine yazılsın",
    "Please choose a mode." : "Lütfen bir kip seçin.",
    "PDF conversion" : "PDF dönüşümü",
    "Convert documents into the PDF format on upload and write." : "Yükleme ve yazma sırasında belgeleri PDF biçimine dönüştürür.",
    "Each rule group consists of one or more rules. A request matches a group if all rules evaluate to true. On creating or writing a file all defined groups are evaluated and when matching, a background job is set up to execute the conversion of the corresponding file." : "Her bir kural grubunda bir ya da bir kaç kural bulunur. Bir isteğin bir gruba uygun olması için gruptaki tüm kurallar karşılanmış olmalıdır. Bir dosyanın eklenebilmesi ya da yazılabilmesi için tanımlanmış gruplar değerlendirilir ve eşleşme varsa ilgili dosya için arka planda yürütülecek bir dönüştürme görevi ayarlanır.",
    "Document to PDF converter" : "Belge PDF dönüştürücü",
    "Automated PDF conversion" : "Otomatik PDF dönüşümü",
    "Rule based conversion of Documents into the PDF format" : "Kurallara göre belgeleri PDF biçimine dönüştürme",
    "An app to trigger automatic conversion of documents to PDF. Based on admin defined rules, a background job file be set up when a matching file was created or written. Then, LibreOffice is being utilized for converting the document." : "Belgelerin PDF biçimine dönüştürülmesi için bir uygulama tetiklenir. Yönetici tarafından oluşturulmuş kurallara uyan bir dosya eklendiğinde ya da kaydedildiğinde bir arka plan görevi dosyası oluşturulur. Ardından belgeyi dönüştürmek için LibreOffice başlatılır."
},
"nplurals=2; plural=(n > 1);");
