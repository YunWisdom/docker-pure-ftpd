OC.L10N.register(
    "gpxpod",
    {
    "download" : "transferir"
},
"nplurals=2; plural=(n != 1);\nX-Generator: crowdin.com\nX-Crowdin-Project: gpxpod\nX-Crowdin-Language: pt-PT");
