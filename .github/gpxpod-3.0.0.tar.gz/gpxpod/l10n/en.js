OC.L10N.register(
    "gpxpod",
    {
    "GpxPod" : "GpxPod"
},
"nplurals=2; plural=(n != 1);\nX-Generator: crowdin.com\nX-Crowdin-Project: gpxpod\nX-Crowdin-Language: en-US");
