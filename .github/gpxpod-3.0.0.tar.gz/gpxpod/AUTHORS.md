# Authors

* Julien Veyssier <eneiluj@posteo.net> (Developper)
* Fritz Kleinschroth <fritz.kln@gmail.com> (German translation)
* Pavel Kardash <slipeer@gmail.com> (Russian translation)
