<?php p($l->t('Hello,')); ?>


<?php p($l->t("We wanted to inform you that %s has published the calendar %s.", [$_['username'],$_['calendarname']])); ?>

<?php p($l->t('Click on the link below to access it')); ?>

<?php p($_['calendarurl']); ?>


<?php p($l->t('Cheers!')); ?>
