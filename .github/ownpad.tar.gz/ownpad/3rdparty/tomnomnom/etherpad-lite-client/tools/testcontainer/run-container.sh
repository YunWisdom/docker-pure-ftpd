#!/bin/sh
sudo docker run --detach --publish=9001:9001 $1
